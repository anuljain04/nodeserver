# nodeserver
to start the server use "node server" in command line